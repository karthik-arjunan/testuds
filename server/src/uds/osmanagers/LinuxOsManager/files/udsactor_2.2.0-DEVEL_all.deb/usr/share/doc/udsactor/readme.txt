UDSActor is the client actor needed to get machines managed by UDS Broker.

Please, visit http://www.udsenterprise.com for more information
