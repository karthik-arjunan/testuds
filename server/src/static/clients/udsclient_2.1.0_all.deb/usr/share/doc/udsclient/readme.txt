UDSClient is the client connector needed to get acccess to services managed by UDS Broker.

Please, visit http://www.udsenterprise.com for more information
